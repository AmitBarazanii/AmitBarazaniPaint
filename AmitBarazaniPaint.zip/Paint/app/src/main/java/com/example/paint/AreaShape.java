package com.example.paint;

public class AreaShape extends Shape {
    public float sizeShape = 0;

    public AreaShape(int x, int y, String color) {
        super(x, y, color);
    }

    @Override
    public void updatePoint(int xe, int ye) {

    }

    public void calculateArea() {


    }

}